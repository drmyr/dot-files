import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment-three',
  templateUrl: './assignment-three.component.html',
  styleUrls: ['./assignment-three.component.css']
})
export class AssignmentThreeComponent implements OnInit {
    displayVisible = true;
    userButtonClicks = [];
  constructor() { }

  ngOnInit() {
  }

    onDisplayClick() {
        this.displayVisible = !this.displayVisible;
        this.userButtonClicks.push(new Date().getTime());
    }

    assignBackgroundColor(click: any) {
        return this.isIndexGreaterThanFive(click) ? 'blue' : 'white';
    }

    shouldTextColorBeWhite(click: any) {
        return this.isIndexGreaterThanFive(click);
    }

    isIndexGreaterThanFive(click: any) {
        return this.userButtonClicks.indexOf(click) > 4;
    }
}
