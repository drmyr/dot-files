export class CounterService {
  private activeSetterUtilizationCount = 0;
  private inactiveSetterUtilizationCount = 0;

  constructor() { }

  activeSetterCalled() {
    this.activeSetterUtilizationCount++;
    console.log('active count ' + this.activeSetterUtilizationCount);
  }

  inactiveSetterCalled() {
    this.inactiveSetterUtilizationCount++;
    console.log('inactive count ' + this.inactiveSetterUtilizationCount);
  }
}
