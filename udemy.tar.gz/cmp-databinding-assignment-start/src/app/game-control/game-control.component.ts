import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-game-control',
  templateUrl: './game-control.component.html',
  styleUrls: ['./game-control.component.css']
})
export class GameControlComponent implements OnInit {
  private setIntervalRef = [];
  private ONE_SECOND = 1000;
  @Output() intervalFired = new EventEmitter<number>();
  private step: number = 0;

  constructor() {

  }

  ngOnInit() {
  }

  onEventStart() {
    this.setIntervalRef.push(setInterval(() => {
      this.intervalFired.emit(this.step + 1);
      this.step++;
      console.log(this.step);
    }, this.ONE_SECOND));
  }

  onEventStop() {
    clearInterval(this.setIntervalRef.pop());
    console.log('stop stop');
  }

}
