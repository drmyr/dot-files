import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {

  public static readonly ENDPOINT: string = 'pageNotFound';
  public static readonly ERROR_MESSAGE: string = 'This is not the page you are looking for';

  constructor() { }

  ngOnInit() {
  }

}
