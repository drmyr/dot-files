import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { UsersComponent } from './users/users.component';
import { ServersComponent } from './servers/servers.component';
import { UserComponent } from './users/user/user.component';
import { EditServerComponent } from './servers/edit-server/edit-server.component';
import { ServerComponent } from './servers/server/server.component';
import { ServersService } from './servers/servers.service';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { AuthGuard } from './auth-guard.service';
import { CanDeactivateGuard } from './servers/edit-server/can-deactivate-guard.service';
import { ServerResolver } from './servers/server/server-resolver.service';

const appRoutes: Routes = [
  { path: '', component: HomeComponent, pathMatch: 'full' },
  { path: UsersComponent.ROUTER_CONTEXT, component: UsersComponent, children: [
    { path: ':id/:name', component: UserComponent }
  ] },
  { path: ServersComponent.ROUTER_CONTEXT,
    //canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
    component: ServersComponent,
    children: [
      { path: ':id',
        component: ServerComponent,
        resolve: { server: ServerResolver } },
      { path: ':id/' + EditServerComponent.ENDPOINT,
        component: EditServerComponent,
        canDeactivate: [CanDeactivateGuard] }
    ]
  },
  //{ path: 'pageNotFound', component: PageNotFoundComponent },
  { path: PageNotFoundComponent.ENDPOINT,
    component: ErrorPageComponent,
    data: {message: PageNotFoundComponent.ERROR_MESSAGE}},
  { path: '**', redirectTo: '/' + PageNotFoundComponent.ENDPOINT } //must be last one
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes, {useHash: true}) //defaults to false.
    //this config enables the hash tag in the url. this is needed
    //for routing in an SPA, because the server doesnt understand SPA routing
    //since the routes it is looking for dont technically exist.
    //The server will ignore everything after the hashtag (so it will only)
    //focus on the host. https://stackoverflow.com/a/41035142
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
