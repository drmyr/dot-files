import { Injectable } from '@angular/core';
import {
  Resolve,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ServersService } from '../servers.service';

export interface Server {
  id: number;
  name: string;
  status: string;
}

//Resolvers should be used when performing async tasks, preventing the view
//from loading until the callback has been resolved.
@Injectable()
export class ServerResolver implements Resolve<Server> {

  constructor(private serverService: ServersService) {}

  //this service will run each time the route is re-rendered,
  //so all we need is the route to get the server id.
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
  Observable<Server> | Promise<Server> | Server {
    return this.serverService.getServer(+route.params['id']);
  }
}
