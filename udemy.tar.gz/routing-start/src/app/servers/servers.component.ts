import { Component, OnInit } from '@angular/core';
import { ServersService } from './servers.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {
  public static readonly ROUTER_CONTEXT: string = 'servers';

  private servers: {id: number, name: string, status: string}[] = [];

  constructor(private serversService: ServersService,
              private router: Router,
              private route: ActivatedRoute) //this gives us access to
              //the currently active route
              { }

  ngOnInit() {
    this.servers = this.serversService.getServers();
  }

  //this method is comented out in the view atm
  onReload() {
    //this.router.navigate(['/servers']);
    this.router.navigate([ServersComponent.ROUTER_CONTEXT]);
  }

}
