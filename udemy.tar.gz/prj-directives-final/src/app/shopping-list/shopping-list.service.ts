import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Ingredient } from '../shared/ingredient.model';

@Injectable()
export class ShoppingListService {
  //ingredientAdded = new EventEmitter<Ingredient[]>(); switch to Observables
  ingredientAdded = new Subject<Ingredient[]>();
  startedEditing = new Subject<number>();
  private ingredients: Ingredient[] = [
    new Ingredient('Apples', 5),
    new Ingredient('Tomatoes', 10),
  ];

  constructor() { }

  addIngredient(ingredient: Ingredient) {
    this.ingredients.push(ingredient);
    this.notifySubscribers();
  }

  private notifySubscribers() {
    this.ingredientAdded.next(this.getIngredients());
  }

  addIngredients(ingredients: Ingredient[]) {
    //ingredients.forEach(this.addIngredient);
    //ingredients.forEach(x => this.addIngredient(x));
    this.ingredients.push(...ingredients);
    this.notifySubscribers();
  }

  updateIngredient(index: number, newIngredient: Ingredient) {
    this.ingredients[index] = newIngredient;
    this.ingredientAdded.next(this.getIngredients());
  }

  getIngredient(index: number) {
    return this.getIngredients()[index];
  }

  getIngredients() {
    return this.ingredients.slice();
  }

}
