import { Component, OnInit } from '@angular/core';

import { RecipeService } from './recipe.service';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css'],
  providers: [RecipeService]
})
export class RecipesComponent implements OnInit {

  public static readonly ROUTER_CONTEXT: string = 'recipes';

  //selectedRecipe: Recipe; dont need this cuz we're using Observables

  constructor() {
    //no longer injecting the RecipeService cuz we are using Observables
  }

  ngOnInit() {
    //removing EventEmitter code so as to favor Observables
    // this.recipeService.recipeSelected.subscribe(
    //   (recipe: Recipe) => {
    //     this.selectedRecipe = recipe;
    //   }
    // );
  }



}
