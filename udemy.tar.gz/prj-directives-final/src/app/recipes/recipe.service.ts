import { Injectable } from '@angular/core';

import { Ingredient } from '../shared/ingredient.model';
import { Recipe } from './recipe.model';

@Injectable()
export class RecipeService {
  //recipeSelected = new EventEmitter<Recipe>(); getting rid of this in
  //favor of Observables
  private recipes: Recipe[] = [
    new Recipe(
      'schnitzel',
      'cool',
      'https://upload.wikimedia.org/wikipedia/commons/1/15/Recipe_logo.jpeg',
      [
        new Ingredient('meat', 1),
        new Ingredient('french fries', 20)
      ]),
    new Recipe(
      'burger',
      'text2',
      'https://upload.wikimedia.org/wikipedia/commons/1/15/Recipe_logo.jpeg',
      [
        new Ingredient('buns', 2),
        new Ingredient('meat', 2)
      ])
  ];

  constructor() { }

  getRecipe(id: number) {
    return this.getRecipes()[id];
  }
  getRecipes() {
    //calling slice with no args creates a copy of the array.
    return this.recipes.slice();
  }

}
