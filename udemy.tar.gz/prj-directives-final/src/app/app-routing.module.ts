import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RecipesComponent } from './recipes/recipes.component';
import { RecipeDetailComponent } from './recipes/recipe-detail/recipe-detail.component';
import { ShoppingListComponent } from './shopping-list/shopping-list.component';
import { RecipeStartComponent } from './recipes/recipe-start/recipe-start.component';
import { RecipeEditComponent } from './recipes/recipe-edit/recipe-edit.component';

const appRoutes: Routes = [
  { path: '',
    redirectTo: '/' + RecipesComponent.ROUTER_CONTEXT,
    pathMatch: 'full' },
  { path: RecipesComponent.ROUTER_CONTEXT,
    component: RecipesComponent,
    children: [
      { path: '',
        component: RecipeStartComponent },
      { path: RecipeEditComponent.ENDPOINT_NEW, //new has to come before id
        component: RecipeEditComponent }, //or else ng will try to parse 'new' as an id
      { path: ':id',
        component: RecipeDetailComponent },
      { path: ':id/' + RecipeEditComponent.ENDPOINT_EDIT,
        component: RecipeEditComponent }
    ]
  },
  { path: ShoppingListComponent.ROUTER_CONTEXT, component: ShoppingListComponent }
];

//bundles all routing functionality
@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
