export class FakeBackendService {
  auth(): any {
    return {
      createUserWithEmailAndPassword: function(email: string, password: string) {
        console.log(email + " " + password);
      },
      signInWithEmailAndPassword: function(email: string, password: string) {
        return new Promise((resolve, reject) => {
          setTimeout(function(){
            resolve("Success!"); // Yay! Everything went well!
          }, 250);
        });
      },
      currentUser: {
        getToken: function() {
          return new Promise((resolve, reject) =>{
            setTimeout(() => {
              resolve("token_555555");
            }, 250);
          });
        }
      }
    };
  }
}
