//import * as firebase from 'firebase';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { FakeBackendService } from '../fake-backend.service';

@Injectable()
export class AuthService {
  token: string;

  constructor(private fakeBackendService: FakeBackendService,
              private router: Router) { }

  signupUser(email: string, password: string) {
    this.fakeBackendService.auth().createUserWithEmailAndPassword(email, password);
    this.getToken();
  }

  signinUser(email: string, password: string) {
    this.fakeBackendService.auth().signInWithEmailAndPassword(email, password)
      .then(
        response => {
          this.getToken();
          this.router.navigate(['/']);
        }
      );
  }

  getToken() {
    this.fakeBackendService.auth().currentUser.getToken().then(
      (token: string) => this.token = token
    );
    return this.token;
  }

  logout() {
    //this.fakeBackendService.auth().signOut();
    this.token = null;
  }

  isAuthenticated() {
    return this.token != null;
  }
}
