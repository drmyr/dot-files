//import * as firebase from 'firebase';
import { Injectable } from '@angular/core';

import { FakeBackendService } from '../fake-backend.service';

@Injectable()
export class AuthService {
  token: string;

  constructor(private fakeBackendService: FakeBackendService) { }

  signupUser(email: string, password: string) {
    this.fakeBackendService.auth().createUserWithEmailAndPassword(email, password);
  }

  signinUser(email: string, password: string) {
    this.fakeBackendService.auth().signInWithEmailAndPassword(email, password)
      .then(
        response => {
          this.getToken();
        }
      );
  }

  getToken() {
    this.fakeBackendService.auth().currentUser.getToken().then(
      (token: string) => this.token = token
    );
    return this.token;
  }

  logout() {

  }
  isAuthenticated() {
    return this.token != null;
  }
}
