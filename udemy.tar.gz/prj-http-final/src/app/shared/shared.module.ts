import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DropdownDirective } from './dropdown.directive';

@NgModule({
  declarations: [
    DropdownDirective
  ],
  exports: [
    CommonModule, //we dont have to import modules to be able to export them
    DropdownDirective
  ]
})
export class SharedModule {}
