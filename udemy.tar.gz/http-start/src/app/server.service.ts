import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';

@Injectable()
export class ServerService {
  private firebaseDB: string = 'https://udemy-ng-http.firebaseio.com/data.json';
  private myheaders = new Headers({'Content-Type': 'application/json'});

  constructor(private http: Http) {}

  storeServers(servers: any[]) {
    return this.http.post(this.firebaseDB, servers, {headers: this.myheaders});
    //the post method creates an observable, but does not send it
    //the request is not sent until someone subscribes to the response.
  }

  updateServer(server: any) {
    return this.http.put(this.firebaseDB, server, {headers: this.myheaders});
  }

  getServers() {
    //better to do data extraction here to make readily usable data available to
    //all components
    return this.http.get(this.firebaseDB)
    .map(
      (response: Response) => {
        const data = response.json();
        for (const server of data) {
          //mod as needed
        }
        return data; //we must return out of map because http needs somthing
        //to wrap in an observable
      }
    ).catch( //similarly, we must return out of the catch as well.
      (response: Response) => {

        return Observable.throw(response);
      }
    );
  }
}
